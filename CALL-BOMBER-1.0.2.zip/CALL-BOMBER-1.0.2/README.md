<p align="center"><img src="https://capsule-render.vercel.app/api?type=waving&color=auto&height=300&section=header&text=CALL%20BOMBER&fontSize=90&animation=fadeIn&fontAlignY=38&desc=AUTO%20CALL%20BOMBING%20TOOLS%20FOR%20SENDING%20SPAM%20CALLS&descAlignY=51&descAlign=62" width="100%"/>
</p>

</p>
   <p align="center">
      <a href="https://github.com/U7P4L-IN/CALL-BOMBER/stargazers">
      <img alt="Stargazers" src="https://img.shields.io/github/stars/U7P4L-IN/CALL-BOMBER?style=for-the-badge&logo=github&color=f4dbd6&logoColor=D9E0EE&labelColor=302D41"></a>
      <a href="https://github.com/U7P4L-IN/CALL-BOMBER/releases/latest">
      <img alt="Releases" src="https://img.shields.io/github/release/U7P4L-IN/CALL-BOMBER?style=for-the-badge&logo=semantic-release&color=f5bde6&logoColor=D9E0EE&labelColor=302D41"/></a>
      <a href="https://www.conventionalcommits.org/en/v1.0.0/">
      <img alt="conventionalcommits" src="https://img.shields.io/badge/Conventional%20Commits-1.0.0-%23FE5196?style=for-the-badge&logo=conventionalcommits&color=ee99a0&logoColor=D9E0EE&labelColor=302D41"></a>
      <a href="https://github.com/U7P4L-IN/CALL-BOMBER/actions/workflows/github-action.yml">
      <img alt="testandlint" src="https://img.shields.io/github/actions/workflow/status/vn7n24fzkq/github-profile-summary-cards/test-and-lint.yml?branch=main&label=Test%20and%20Lint&style=for-the-badge&color=a6da95"></a>
   </p>
   
</br>

> A Call Bomber is a tool or software that automatically sends a large volume of calls to a specific phone number in a short period.

> Call bombers are usually used as a form of revenge, prank, or even cyberbullying. Call bombers work by using an auto-dialer to call a target number repeatedly, often hundreds of times per hour.

<br>
<h4 align="center">DISCLAIMER > </h4><br>

* This Tool is for Educatinal Purposes only! don't use this to take revenge
* I will not br responsible for any misuse
<br>
<h4 align="left">About > </h4><br>

* Unlimited Usage !
* Support Newest Android also
* Working Apis
* Working with all Oparetors/Carriers
<br>
<h4 align="left">TESTED ON > </h4><br>

* Kali Linux
* Termux
* Mac os
* Ubuntu
* Perrot Sec OS

<br><h4 align="left">Log In Password  > </h4>

```python
PASSWORD : U7P4L
```

<br>
<h4 align="left">INSTALL TOOL ON TERMUX > </h4>
 
```python
apt update && apt upgrade -y
pkg install git
pkg install python
pip install requests
rm -rf CALL-BOMBER
git clone --depth=1 https://github.com/U7P4L-IN/CALL-BOMBER.git
cd CALL-BOMBER
python BOMBER.py
```
<p align="center"><img src="/image/carbon.png">

<h5 align="center"><b>TERMUX</b></h5>

<p align="center"><img src="/image/demo1.jpg">
<p align="center";><img src="/image/demo2.jpg"> 

<h5 align="center"><b>KALI LINUX</b></h5>

<p align="center"><img src="/image/demo3.png">
<p align="center"><img src="/image/demo4.png">
    
</br>

<p align="center">  <a href="https://t.me/TheU7p4lArmyX"><img width="300" height="100" src="https://i.imgur.com/N7AK7XY.png"></a></p>

</br>

### Tools Languages :

<p align="center"><img src="https://github-readme-stats.vercel.app/api/pin?username=U7P4L-IN&repo=CALL-BOMBER&title_colo
r=fff&icon_color=f9f9f9&text_color=9f9f9f&bg_color=151515" width="100%"/>
</p>

<h2 align="center">LICENSE</h2>

Call Bomber is released under the AGPL-3.0 license, which grants the following permissions:
- Commercial use
- Modification
- Distribution
- Patent use
- Private use

For more convoluted language, see the [LICENSE](/LICENSE).
</br>

<h5 align="center"><b>DESCRIPTION</b></h5>

> [!NOTE]  
> All the tools are belongs to their copyright owner, and this use is in accordance with the terms and conditions of the copyright holder.

# Give A Star ⭐

> You can also give this repository a star to show more people and they can use this repository
